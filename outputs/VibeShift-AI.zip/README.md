# VibeShift AI

VibeShift AI is a private communication workspace for rewriting drafts by audience and tone. It computes text differences and word counts in the browser, provides a deterministic, explicitly heuristic tone estimate, and uses a configurable backend text-generation provider for rewrites. It does not fabricate output when inference is unavailable.

## Features

- Four configurable personas and three length preferences.
- Optional context, audience, and target language.
- Backend text generation with request validation, timeouts, and clear provider errors.
- Word-level insertion/deletion highlights and word count change calculated from actual text.
- Text-based tone estimates with cue phrases and uncertainty disclosure.
- Browser speech recognition (when supported), browser text-to-speech, and image preview.
- SQLite registration/login endpoints with password hashing and per-account history ownership.
- Responsive light/dark workspace.

## Requirements

- Node.js 20+ and npm.
- Python 3.10+.
- For real AI transformations, a Gemini API key is required. The app defaults to a Gemini OpenAI-compatible endpoint and `gemini-3.5-flash-lite`.

## Run locally

From the repository root:

```powershell
npm install
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r backend/requirements.txt
Copy-Item backend/.env.example backend/.env
```

Edit `backend/.env` and set `AI_API_KEY` to a Gemini key. The default base URL and model are preconfigured in `backend/.env.example`; leave the Google Cloud project on the free tier and do not enable billing. Flask loads `backend/.env` relative to `backend/app.py` on startup. Then run:

```powershell
python backend/app.py
```

In another terminal:

```powershell
npm run dev
```

Open the Vite URL printed in the terminal. The UI proxies `/api` requests to Flask at `127.0.0.1:5000`.

## Environment

| Name | Purpose |
|---|---|
| `FLASK_SECRET_KEY` | Required for secure production sessions. The development fallback must not be used on a public deployment. |
| `AI_API_KEY` | Backend-only provider key. Required for real rewrite inference. |
| `AI_BASE_URL` | Defaults to Gemini’s OpenAI-compatible endpoint: `https://generativelanguage.googleapis.com/v1beta/openai/`. |
| `AI_MODEL` | Defaults to `gemini-3.5-flash-lite`, currently listed with free-tier input and output. |
| `COOKIE_SECURE` | Set to `1` behind HTTPS in production. |

The backend uses the Chat Completions-compatible REST interface. Google documents this compatibility, including the Gemini endpoint and model names, in its [OpenAI compatibility guide](https://ai.google.dev/gemini-api/docs/openai/). Google’s [pricing page](https://ai.google.dev/gemini-api/docs/pricing) currently lists `gemini-3.5-flash-lite` with free-tier text input and output, subject to account, region, rate, and quota limits. It still requires an API key. Create the key in [Google AI Studio](https://aistudio.google.com/apikey) for a project with no billing enabled; do not select or attach a paid-billing project. Free-tier submitted content may be used by Google to improve products according to its pricing disclosure, so avoid confidential messages unless that is acceptable. The app never turns on billing. Provider credentials stay in `backend/.env`, which is gitignored. If the free quota is exhausted, the app returns a retry-later message; it will not upgrade the account.

## Run provider tests

Run `python -m unittest tests.test_provider -v`. The tests mock provider responses to verify endpoint JSON and error handling. They do not make a real Gemini request. A successful live transformation requires your own API key.

## Local-only / external capabilities

- Text length counts, diff, and heuristic tone analysis run locally in the browser/backend and need no paid API.
- Text rewrite requires a Gemini API key. `gemini-3.5-flash-lite` is listed as free-tier for text input/output at the time this README was updated; quota and access can vary by region/project. No billing is enabled by this app.
- Browser speech recognition depends on browser support and permissions; recognition may be processed by the browser vendor. Browser speech synthesis uses the installed browser/OS voices and does not apply genuine expressive controls beyond rate adjustment.
- Image upload preview is local. OCR endpoint returns an explicit not-configured error; no image is permanently stored.
- Server-side transcription returns an explicit not-configured error.

## Accounts and history

Registration, login, session, and ownership-enforced history endpoints are implemented. Anonymous transformations are not persisted. The UI's current history list is in-memory for the current page session; the account endpoints are available to integrate with an account UI. SQLite stores salted password hashes and account transformation data. Deleting a history entry or clearing history is supported by the API. Use HTTPS and a secret key for deployment; production CSRF protections and rate limiting should be added before exposing public registration.

## API

- `GET /api/health`, `GET /api/session`
- `POST /api/register`, `POST /api/login`, `POST /api/logout`
- `POST /api/transform`, `POST /api/analyze-tone`
- `GET /api/history`, `GET /api/history/<id>`, `DELETE /api/history`, `DELETE /api/history/<id>`
- `POST /api/transcribe`, `POST /api/analyze-image`

## Limitations

Authentication endpoints and protected history operations are implemented, but a registration/login UI is not included yet. History shown in the current interface is session-memory only. Image OCR and backend transcription are intentionally not faked and return setup errors. Tone analysis is a transparent keyword heuristic, not an ML classifier or a judgment of a person. Only English browser recognition is selected by the voice button. Target language choices depend on the configured model; browser TTS may lack the selected language voice. The provider endpoint tests use mocked HTTP responses; no live-provider inference test runs without a user-supplied key.

